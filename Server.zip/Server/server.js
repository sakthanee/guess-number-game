var app = require('express')();
var server = require('http').Server(app);
var io = require('socket.io')(server);

var SugNumber = getRandomInt(100);

server.listen(5000, function () {
    console.log("current Number is " + SugNumber);
});

io.on('connection', function (socket) {
    socket.emit('login');

    socket.on('login success', function (data) {
        console.log(data.name + " has login");
    });

    socket.on('request suggest', function (data) {
        console.log(data.name + " has request: " + data.number);
        if (data.number == SugNumber) {
            var checkResult = {
                name: data.name,
                status: 0
            }
            socket.broadcast.emit('return result',checkResult);
            socket.emit('return result',checkResult);
            console.log(data.name+" win!!");
            SugNumber = getRandomInt(100);
            console.log("The new Number has been created");
            console.log("Current Number is " + SugNumber);
            socket.emit('New Number created');
            socket.broadcast.emit('New Number created');
        }
        else {
            var resResult = 0;
            if(data.number < SugNumber)
            {
                resResult = -1;
            }
            else
            {
                resResult = 1;
            }
            var checkResult={
                name:data.name,
                status:resResult
            }
            socket.emit('return result',checkResult);
            console.log(data.name+" is not correct");
        }
    })
});

function getRandomInt(max) {
    return Math.floor(Math.random() * Math.floor(max));
}

console.log("Server Starting!");